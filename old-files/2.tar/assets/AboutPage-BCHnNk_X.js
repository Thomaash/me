import{An as e,Cn as t,Dn as n,En as r,Jn as i,Kn as a,Mn as o,On as s,jn as c,kn as l,nr as u,wr as d,yr as f}from"./position-J01Ss8ab.js";import{n as p,r as m,t as h}from"./VRow-DP6AZ3Y2.js";import{m as g}from"./js/app-DrS8X5m9.js";import{t as _}from"./useTopologyStore-D2yoU9M9.js";import{n as v,t as y}from"./AppLogo-DrC-Z6yt.js";var b={key:0},x=Object.assign({name:`BuildInfo`},{__name:`BuildInfo`,setup(t){let{isUpdateAvailable:r}=_(),i=`05aec372b6ea212cca492dbf5c204d6fddaaeaab`;return(t,s)=>(a(),e(`section`,null,[s[4]||=n(`h3`,{class:`text-h6`},`Build`,-1),n(`p`,null,[c(` Build date: `+d(f(`2026-04-25T17:44:29.661Z`))+` `,1),s[1]||=n(`br`,null,null,-1),c(` Commit date: `+d(f(`2026-04-25T17:43:33.000Z`))+` `,1),s[2]||=n(`br`,null,null,-1),c(` Commit hash: `+d(f(i))+` `,1),s[3]||=n(`br`,null,null,-1),o(g,{class:`ma-2`,variant:`outlined`,color:`primary`,target:`_blank`,href:`https://github.com/Thomaash/me/commit/`+f(i)},{default:u(()=>[...s[0]||=[c(` Open on GitHub `,-1)]]),_:1},8,[`href`])]),f(r)?(a(),e(`p`,b,` A new version is available and will be automatically installed when you close all open tabs. `)):l(``,!0)]))}}),S=`ISC License

Copyright (c) 2018-2025, Tomáš Vyčítal

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted, provided that the above
copyright notice and this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
`,C=[`textContent`],w=Object.assign({name:`AppLicense`},{__name:`AppLicense`,setup(o){let s=r(()=>S.split(/\n\n/g));return(r,o)=>(a(),e(`section`,null,[o[0]||=n(`h3`,{class:`text-h6`},`License`,-1),(a(!0),e(t,null,i(s.value,(t,n)=>(a(),e(`p`,{key:`license_p_`+n,textContent:d(t)},null,8,C))),128))]))}}),T={__name:`AboutPage`,setup(e){return(e,t)=>(a(),s(m,{"grid-list-md":``},{default:u(()=>[o(h,{wrap:``},{default:u(()=>[o(y),o(p,{cols:`12`},{default:u(()=>[o(v,{full:``})]),_:1}),o(p,{cols:`12`},{default:u(()=>[o(w)]),_:1}),o(p,{cols:`12`},{default:u(()=>[o(x)]),_:1})]),_:1})]),_:1}))}};export{T as default};