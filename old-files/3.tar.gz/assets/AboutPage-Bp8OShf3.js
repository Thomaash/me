import{$n as e,Dr as t,Gn as n,Jn as r,Kr as i,Qn as a,Qr as o,Xn as s,Yn as c,Zn as l,er as u,gr as d,vr as f}from"./position-BtJXvoBn.js";import{g as p,m}from"./js/app-DidW8v4Y.js";import{n as h,t as g}from"./AppLogo-CHbLGwQj.js";import{n as _,r as v,t as y}from"./VRow-BPYa8dCv.js";var b={key:0},x=Object.assign({name:`BuildInfo`},{__name:`BuildInfo`,setup(n){let r=p(),s=`a8157c67a2b3e7dcea0b22b4b3c1e4f3f67b0747`;return(n,f)=>(d(),a(`section`,null,[f[4]||=c(`h3`,{class:`text-h6`},`Build`,-1),c(`p`,null,[e(` Build date: `+o(i(`2026-11-08T21:56:48.615Z`))+` `,1),f[1]||=c(`br`,null,null,-1),e(` Commit date: `+o(i(`2026-11-08T21:55:49.000Z`))+` `,1),f[2]||=c(`br`,null,null,-1),e(` Commit hash: `+o(i(s))+` `,1),f[3]||=c(`br`,null,null,-1),u(m,{class:`ma-2`,variant:`outlined`,color:`primary`,target:`_blank`,href:`https://github.com/Thomaash/me/commit/`+i(s)},{default:t(()=>[...f[0]||=[e(` Open on GitHub `,-1)]]),_:1},8,[`href`])]),i(r).isUpdateAvailable?(d(),a(`p`,b,` A new version is available and will be automatically installed when you close all open tabs. `)):l(``,!0)]))}}),S=`ISC License

Copyright (c) 2018-2026, Tomáš Vyčítal

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted, provided that the above
copyright notice and this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
`,C=[`textContent`],w=Object.assign({name:`AppLicense`},{__name:`AppLicense`,setup(e){let t=r(()=>S.split(/\n\n/g));return(e,r)=>(d(),a(`section`,null,[r[0]||=c(`h3`,{class:`text-h6`},`License`,-1),(d(!0),a(n,null,f(t.value,(e,t)=>(d(),a(`p`,{key:`license_p_`+t,textContent:o(e)},null,8,C))),128))]))}}),T={__name:`AboutPage`,setup(e){return(e,n)=>(d(),s(v,{"grid-list-md":``},{default:t(()=>[u(y,{wrap:``},{default:t(()=>[u(g),u(_,{cols:`12`},{default:t(()=>[u(h,{full:``})]),_:1}),u(_,{cols:`12`},{default:t(()=>[u(w)]),_:1}),u(_,{cols:`12`},{default:t(()=>[u(x)]),_:1})]),_:1})]),_:1}))}};export{T as default};